DARK_THEME = {
    "background": "#121212",
    "foreground": "#FFFFFF",
    "hover_button_1": "#FF69B4",  # Pink
    "hover_button_2": "#9370DB",  # Purple
    "hover_button_3": "#00FFFF",  # Cyan
    "cursor_color": "#00FF00",    # Green
    "editor_background": "#1E1E1E",
    "status_bar_bg": "#333333",
    "status_bar_fg": "#FFFFFF"
}
