import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QTextEdit, QVBoxLayout, QWidget, QMenuBar, QMenu, QAction
from gui.themes import DARK_THEME
from gui.tab_manager import TabManager
from gui.status_bar import StatusBar
from gui.save_manager import SaveManager

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Modern Text Editor")
        self.setGeometry(100, 100, 800, 600)
        self.setStyleSheet(f"background-color: {DARK_THEME['background']}; color: {DARK_THEME['foreground']};")

        # Tab Manager
        self.tab_manager = TabManager(self)
        self.setCentralWidget(self.tab_manager)

        # Menu Bar
        self.init_menu_bar()

        # Status Bar
        self.status_bar = StatusBar(self)
        self.setStatusBar(self.status_bar)

        # Save Manager
        self.save_manager = SaveManager(self.tab_manager)

        # Signal Connections
        self.tab_manager.text_changed.connect(self.status_bar.update_status)

    def init_menu_bar(self):
        menu_bar = self.menuBar()
        menu_bar.setStyleSheet(f"background-color: {DARK_THEME['status_bar_bg']}; color: {DARK_THEME['status_bar_fg']};")

        file_menu = menu_bar.addMenu("File")
        
        # New File
        new_file_action = QAction("New", self)
        new_file_action.triggered.connect(self.tab_manager.new_tab)
        file_menu.addAction(new_file_action)

        # Open File
        open_file_action = QAction("Open", self)
        open_file_action.triggered.connect(self.save_manager.open_file)
        file_menu.addAction(open_file_action)

        # Save File
        save_file_action = QAction("Save", self)
        save_file_action.triggered.connect(self.save_manager.save_file)
        file_menu.addAction(save_file_action)

        # Save As
        save_as_action = QAction("Save As", self)
        save_as_action.triggered.connect(self.save_manager.save_file_as)
        file_menu.addAction(save_as_action)

        # Exit
        exit_action = QAction("Exit", self)
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)
