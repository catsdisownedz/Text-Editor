from PyQt5.QtGui import QFont
from gui.syntax_highlighter import SyntaxHighlighter

class TabManager(QTabWidget):
    def __init__(self, parent):
        super().__init__(parent)
        self.setTabsClosable(True)
        self.setMovable(True)
        self.setStyleSheet(f"background-color: {DARK_THEME['editor_background']};")

    def new_tab(self):
        editor = QTextEdit()
        editor.setStyleSheet(f"color: {DARK_THEME['foreground']}; background-color: {DARK_THEME['editor_background']};"
                             f" selection-background-color: {DARK_THEME['hover_button_1']};")
        editor.setFont(QFont("Courier", 12))
        editor.setCursorWidth(3)
        editor.setOverwriteMode(False)

        # Apply syntax highlighting
        SyntaxHighlighter(editor.document())

        self.addTab(editor, "Untitled")
        self.setCurrentWidget(editor)

    def current_editor(self):
        return self.currentWidget()
