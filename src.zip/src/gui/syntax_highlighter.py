from PyQt5.QtGui import QTextCharFormat, QFont, QSyntaxHighlighter, QColor
import re

class SyntaxHighlighter(QSyntaxHighlighter):
    def __init__(self, document):
        super().__init__(document)
        self.error_format = QTextCharFormat()
        self.error_format.setUnderlineStyle(QTextCharFormat.SpellCheckUnderline)
        self.error_format.setUnderlineColor(QColor("red"))
        self.error_format.setForeground(QColor("red"))

        self.keyword_format = QTextCharFormat()
        self.keyword_format.setForeground(QColor("cyan"))
        self.keyword_format.setFontWeight(QFont.Bold)

        self.valid_keywords = ["start", "end", "if", "else", "print"]

#honestly this function is just a placeholder for what we are acually gonna do 
    def highlightBlock(self, text):
        # Highlight valid keywords
        for keyword in self.valid_keywords:
            for match in re.finditer(rf'\b{keyword}\b', text):
                self.setFormat(match.start(), match.end() - match.start(), self.keyword_format)

        # Check for invalid syntax (non-alphanumeric characters except valid ones)
        tokens = re.findall(r"\b[a-zA-Z_][a-zA-Z0-9_]*\b", text)
        for token in tokens:
            if token not in self.valid_keywords:
                match = re.search(rf"\b{token}\b", text)
                if match:
                    self.setFormat(match.start(), match.end() - match.start(), self.error_format)
