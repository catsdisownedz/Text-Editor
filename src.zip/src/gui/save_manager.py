import os
from PyQt5.QtWidgets import QFileDialog, QMessageBox
from gui.themes import DARK_THEME

class SaveManager:
    def __init__(self, tab_manager):
        self.tab_manager = tab_manager
        self.current_file = None

    def save_file(self):
        current_editor = self.tab_manager.current_editor()
        if not current_editor:
            QMessageBox.warning(None, "Warning", "No file open to save.")
            return
        
        if self.current_file:
            with open(self.current_file, "w") as file:
                file.write(current_editor.toPlainText())
            QMessageBox.information(None, "Success", f"File saved: {self.current_file}")
        else:
            self.save_file_as()

    def save_file_as(self):
        current_editor = self.tab_manager.current_editor()
        if not current_editor:
            QMessageBox.warning(None, "Warning", "No file open to save.")
            return

        file_path, _ = QFileDialog.getSaveFileName(None, "Save As", "", "Text Files (*.txt);;All Files (*)")
        if file_path:
            self.current_file = file_path
            with open(file_path, "w") as file:
                file.write(current_editor.toPlainText())
            QMessageBox.information(None, "Success", f"File saved as: {file_path}")

    def open_file(self):
        file_path, _ = QFileDialog.getOpenFileName(None, "Open File", "", "Text Files (*.txt);;All Files (*)")
        if file_path:
            with open(file_path, "r") as file:
                content = file.read()
            self.tab_manager.new_tab()
            current_editor = self.tab_manager.current_editor()
            current_editor.setPlainText(content)
            self.current_file = file_path
            QMessageBox.information(None, "Success", f"File opened: {file_path}")
