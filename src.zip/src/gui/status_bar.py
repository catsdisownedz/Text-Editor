from PyQt5.QtWidgets import QStatusBar, QLabel
from gui.themes import DARK_THEME

class StatusBar(QStatusBar):
    def __init__(self, parent):
        super().__init__(parent)
        self.setStyleSheet(f"background-color: {DARK_THEME['status_bar_bg']}; color: {DARK_THEME['status_bar_fg']};")
        
        self.line_count_label = QLabel("Lines: 0")
        self.language_label = QLabel("Language: Text")
        
        self.addWidget(self.line_count_label)
        self.addWidget(self.language_label)

    def update_status(self, text):
        lines = len(text.split('\n'))
        self.line_count_label.setText(f"Lines: {lines}")
        if text.strip().startswith("soso"):
            self.language_label.setText("Language: Soso")
        else:
            self.language_label.setText("Language: Text")
